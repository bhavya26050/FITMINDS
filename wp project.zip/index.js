const express = require("express");
const app = express();
const mysql = require("mysql");
const session = require("express-session");
const bodyParser = require("body-parser");

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var conn = mysql.createConnection({
    host: 'localhost',
    user: "root",
    password: "",
    database: "gym"
});

app.set('view engine', 'hbs');


app.get('/landing', function (req, res) {
    res.render('landing');
});

app.get('/', function (req, res) {
    res.redirect('/landing');
});

app.get('/signup', function (req, res) {
    res.render('signup');
});
app.post('/signup', function (req, res) {
    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
  
    const phone = req.body.phone;

    var sql = `SELECT email FROM users WHERE email = ?`;
    conn.query(sql, [email], function (error, result) {
        if (error) {
            console.error(error);
            return res.render('signup', { message: 'Error occurred' });
        }

        if (result.length > 0) {
            return res.render('signup', { message: 'Email is already in use' });
        }

        var insertSql = `INSERT INTO users (Name, email, password, phoneno) VALUES (?, ?, ?, ?)`;
        conn.query(insertSql, [name, email, password, phone], function (insertError, insertResult) {
            if (insertError) {
                console.error(insertError);
                return res.render('signup', { message: 'Error occurred during registration' });
            }
          
            return res.redirect("/login");
         
  
        });
    });
});


app.get('/login', function (req, res) {
    res.render('login');
});
app.get('/about', function (req, res) {
    res.render('about');
});
app.get('/contact', function (req, res) {
    res.render('contact');
});
app.get('/nutrition', function (req, res) {
    res.render('nutrition');
});
app.get('/payment', function (req, res) {
    res.render('payment');
});
app.get('/plan', function (req, res) {
    res.render('plan');
});
app.get('/plan2', function (req, res) {
    res.render('plan2');
});
app.get('/registration', function (req, res) {
    res.render('registration');
});
app.get('/weight', function (req, res) {
    res.render('weight');
});
app.get('/strength', function (req, res) {
    res.render('strength');
});
app.get('/main_plan', function (req, res) {
    res.render('main_plan');
});
app.get('/dash', function (req, res) {
    res.render('dash');
});
app.post('/login', function (req, res) {
    var email = req.body.email;
    var password = req.body.password;

    if (email && password) {
        var sql = `SELECT * FROM users WHERE email = ? AND password = ?`;
        conn.query(sql, [email, password], function (err, result) {
            if (err) {
                console.error(err);
                res.render('login', { message: 'An error occurred. Please try again.' });
            } else if (result.length > 0) {
                var user = result[0];
                req.session.loggedin = true;
                req.session.email = email;
                req.session.userId = user.Id; // Storing user's ID in the session
                var email = user.email;

              
                res.render('dash', { email: email });// replace it with welcome page
                res.redirect("/dash");//same goes here
            } else {
                res.render('login', { message: 'Incorrect email or password.' });
            }
        });
    } else {
        res.render('login', { message: 'Please enter email and password.' });
    }
});
// app.post('/login', function (req, res) {
//     var username = req.body.email;
//     var password = req.body.password;
    
//     if (username && password) {
//         var sql = `SELECT * FROM users WHERE email='${username}' && password='${password}'`;
//         conn.query(sql, function (err, result) {
//             if (result.length > 0) {
//                 req.session.loggedin = true;
//                 req.session.username = username;
//                 res.redirect('/welcome');
//             } else {
//                 res.render('login', { message: 'Incorrect details' });
//             }
//         });
//     } else {
//         res.render('login', { message: 'Please enter details' });
//     }
// });

app.get('/dash', function (req, res) {
    if (req.session.loggedin) {
        res.render('dash', { user: email });
    } else {
        res.redirect('/login');
    }
});

app.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error(err);
        }
        res.redirect('/login');
    });
});

app.listen(20000, () => {
    console.log('Server is running on port 20000');
});
